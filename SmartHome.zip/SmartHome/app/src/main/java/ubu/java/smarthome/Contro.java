package ubu.java.smarthome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.hookedonplay.decoviewlib.DecoView;
import com.hookedonplay.decoviewlib.charts.SeriesItem;
import com.hookedonplay.decoviewlib.events.DecoEvent;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

public class Contro extends AppCompatActivity {
    private SeekBar BarTempSetting;
    private TextView TempSetting , TemOut, TemIn;

    private ImageView Setting;

    Vibrator vibrator ;


    private static Socket s;
    private static ServerSocket ss;
    private static InputStreamReader isr;
    private static BufferedWriter bw;
    private static BufferedReader br;
    private static PrintWriter printWriter;
    private String ips;
    private String message;

    final int min = 16;
    final int max = 40;


    private ToggleButton TB_1, TB_2, TB_3, TB_4, TB_5, TB_6, TB_7, TB_8, TB_9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contro);

        final DecoView arcView = (DecoView)findViewById(R.id.dynamicArcView);
        BarTempSetting = (SeekBar) findViewById(R.id.BarTempSetting);
        Setting = (ImageView) findViewById(R.id.Setting);
        TempSetting = (TextView)  findViewById(R.id.TempSetting); TemOut = (TextView) findViewById(R.id.TemOut); TemIn = (TextView) findViewById(R.id.TemIn); TemOut= (TextView) findViewById(R.id.TemOut);
        TB_1 = (ToggleButton) findViewById(R.id.TB_1); TB_2 = (ToggleButton) findViewById(R.id.TB_2); TB_3 = (ToggleButton) findViewById(R.id.TB_3); TB_4 = (ToggleButton) findViewById(R.id.TB_4);         TB_5 = (ToggleButton) findViewById(R.id.TB_5); TB_6 = (ToggleButton) findViewById(R.id.TB_6); TB_7 = (ToggleButton) findViewById(R.id.TB_7); TB_8 = (ToggleButton) findViewById(R.id.TB_8); TB_9 = (ToggleButton) findViewById(R.id.TB_9);

        Bundle bundle = getIntent().getExtras();
        this.ips = bundle.getString("IPS");

        final int random1 = new Random().nextInt((max - min) + 1) + min;
        final int random2 = new Random().nextInt((max - min) + 1) + min;

        TemIn.setText(random1+"°C");
        TemOut.setText(random2+"°C");

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);


        // Create background track temp
            arcView.addSeries(new SeriesItem.Builder(Color.argb(50, 228, 49, 104))
                .setRange(0, 100, 100)
                .setInitialVisibility(false)
                .setLineWidth(60f)
                .build());

        //Create data series track temp
        SeriesItem seriesItem1 = new SeriesItem.Builder(Color.argb(200, 0, 0, 255), Color.argb(255, 255, 0, 0))
                .setRange(0, 100, 0)
                .setLineWidth(60f)
                .setShadowSize(40)
                .setShadowColor(Color.DKGRAY)
                .build();

        arcView.addEvent(new DecoEvent.Builder(DecoEvent.EventType.EVENT_SHOW, true)
                .setDuration(2000)
                .build());

        arcView.configureAngles(250, 0);
        final int series1Index = arcView.addSeries(seriesItem1);




        TB_1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_1.getText().toString()+" : ON");
                } else {
                    SandMess(TB_1.getText().toString()+" : OFF");
                }
            }
        });

        TB_2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_2.getText().toString()+" : ON");
                } else {
                    SandMess(TB_2.getText().toString()+" : OFF");
                }
            }
        });

        TB_3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_3.getText().toString()+" : ON");
                } else {
                    SandMess(TB_3.getText().toString()+" : OFF");
                }
            }
        });

        TB_4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_4.getText().toString()+" : ON");
                } else {
                    SandMess(TB_4.getText().toString()+" : OFF");
                }
            }
        });

        TB_5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_5.getText().toString()+" : ON");
                } else {
                    SandMess(TB_5.getText().toString()+" : OFF");
                }
            }
        });

        TB_6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_6.getText().toString()+" : ON");
                } else {
                    SandMess(TB_6.getText().toString()+" : OFF");
                }
            }
        });

        TB_7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_7.getText().toString()+" : ON");
                } else {
                    SandMess(TB_7.getText().toString()+" : OFF");
                }
            }
        });

        TB_8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_8.getText().toString()+" : ON");
                } else {
                    SandMess(TB_8.getText().toString()+" : OFF");
                }
            }
        });

        TB_9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                notification();
                if (b) {
                    SandMess(TB_9.getText().toString()+" : ON");
                } else {
                    SandMess(TB_9.getText().toString()+" : OFF");
                }
            }
        });

        Setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Contro.this, SettingB.class);
                startActivity(intent);
            }
        });



        //บาปรับอุหภูมิ
        BarTempSetting.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            private String TempSet;

            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                arcView.addEvent(new DecoEvent.Builder(i)
                        .setIndex(series1Index)
                        .build());
                TempSetting.setText(i+"°C");
                TempSet = ""+i;
                notification();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                SandMess("TempSetting : "+TempSet);
            }
        });
    }

    void notification () {
        vibrator.vibrate(250);
    }


    void SandMess (String Mess) {
        final ConnToS c = new ConnToS();
        c.execute(ips,Mess);
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    class ConnToS extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... data) {
            int counts = 0;
            try {
                s = new Socket(data[0],8888);
//                if (data[] == "GTemp") {
//                    printWriter = new PrintWriter(s.getOutputStream());
//                    printWriter.write(data[1]);
//                    printWriter.flush();
//                    printWriter.close();
//                    isr = new InputStreamReader(s.getInputStream());
//                    br = new BufferedReader(isr);
//                    setMessage(br.readLine());
//                    counts++; } 
                if(counts != 0) {
                    printWriter = new PrintWriter(s.getOutputStream());
                    printWriter.write(data[1]);
                    printWriter.flush();
                    printWriter.close();

                } else {
                    printWriter = new PrintWriter(s.getOutputStream());
                    printWriter.write(data[1]);
                    printWriter.flush();
                    printWriter.close();
                }
                s.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
