package ubu.java.smarthome;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class listconnet extends AppCompatActivity {

    private static Socket s;
    private static ServerSocket ss;
    private static InputStreamReader isr;
    private static BufferedWriter br;
    private static PrintWriter printWriter;
    TextView IIp;
    Button Bconn;
    private static String ip;
    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView IIp = (TextView)findViewById(R.id.IIp);
        Button Bconn = (Button)findViewById(R.id.BConn);
        progressDialog = new ProgressDialog(this);
        final String ips = IIp.getText().toString();


        Bconn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog.setMessage("กําลังเชื่อมต่อ...");
                progressDialog.show();
                ConnToServer c = new ConnToServer();
                c.execute(ips);
            }
        });
    }

    class ConnToServer extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... ip) {
            try {
                s = new Socket(ip[0],8888);
                printWriter = new PrintWriter(s.getOutputStream());
                printWriter.write("Hello_Server");
                printWriter.flush();
                printWriter.close();
                s.close();
                setIp(ip[0]);
                GoToContro();
                progressDialog.dismiss();
            } catch (IOException e) {
                e.printStackTrace();
                progressDialog.dismiss();
            }
            return null;
        }
    }

    private void GoToContro() {
        Intent intent = new Intent(listconnet.this, Contro.class);
        intent.putExtra("IPS", getIp());
        startActivity(intent);
    }

    public static String getIp() {
        return ip;
    }

    public static void setIp(String ip) {
        listconnet.ip = ip;
    }


}

