package ubu.java.smarthome;

import android.graphics.drawable.Drawable;

public class Setting {
    private String[] pin;
    private String RoomName;
    private Drawable icon;


    public String getRoomName() {
        return RoomName;
    }

    public void setRoomName(String roomName) {
        RoomName = roomName;
    }

    public Drawable getIcon() {
        return icon;
    }

    public void setIcon(Drawable icon) {
        this.icon = icon;
    }

    public String[] getPin() {
        return pin;
    }

    public void setPin(String[] pin) {
        this.pin = pin;
    }
}
