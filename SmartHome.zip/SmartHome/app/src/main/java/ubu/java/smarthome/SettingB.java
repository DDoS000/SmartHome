package ubu.java.smarthome;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class SettingB extends AppCompatActivity {

    Button TB_1, TB_2, TB_3, TB_4, TB_5, TB_6, TB_7, TB_8, TB_9, DEMOSHOW , SAVE;
    EditText RoomName, pinon, pinoff;
    Spinner Icon;

    Setting TB1, TB2, TB3, TB4, TB5, TB6, TB7, TB8, TB9, DS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_b);
// ยังไม่เสร็จดี
        TB_1 = (Button) findViewById(R.id.TB_1);
        TB_2 = (Button) findViewById(R.id.TB_2);
        TB_3 = (Button) findViewById(R.id.TB_3);
        TB_4 = (Button) findViewById(R.id.TB_4);
        TB_5 = (Button) findViewById(R.id.TB_5);
        TB_6 = (Button) findViewById(R.id.TB_6);
        TB_7 = (Button) findViewById(R.id.TB_7);
        TB_8 = (Button) findViewById(R.id.TB_8);
        TB_9 = (Button) findViewById(R.id.TB_9);
        DEMOSHOW = (Button) findViewById(R.id.DEMOSHOW);
        SAVE = (Button) findViewById(R.id.Save);

        RoomName = (EditText) findViewById(R.id.RoomName); pinon = (EditText) findViewById(R.id.pinon); pinoff = (EditText) findViewById(R.id.pinoff);

        Icon = (Spinner) findViewById(R.id.Icon);


        TB1 = new Setting();
        TB1.setIcon(getResources().getDrawable(R.drawable.ledbutton));
        TB1.setRoomName("Light Room 1");
        TB1.setPin(new String[]{"ON", "OFF"});

        TB2 = new Setting();
        TB2.setIcon(getResources().getDrawable(R.drawable.ledbutton));
        TB2.setRoomName("Light Room 2");
        TB2.setPin(new String[]{"ON", "OFF"});

        TB3 = new Setting();
        TB3.setIcon(getResources().getDrawable(R.drawable.ledbutton));
        TB3.setRoomName("Light Room 3");
        TB3.setPin(new String[]{"ON", "OFF"});

        TB4 = new Setting();
        TB4.setIcon(getResources().getDrawable(R.drawable.fanbutton));
        TB4.setRoomName("Fan Room 1");
        TB4.setPin(new String[]{"ON", "OFF"});

        TB5 = new Setting();
        TB5.setIcon(getResources().getDrawable(R.drawable.fanbutton));
        TB5.setRoomName("Fan Room 2");
        TB5.setPin(new String[]{"ON", "OFF"});

        TB6 = new Setting();
        TB6.setIcon(getResources().getDrawable(R.drawable.fanbutton));
        TB6.setRoomName("Fan Room 3");
        TB6.setPin(new String[]{"ON", "OFF"});

        TB7 = new Setting();
        TB7.setIcon(getResources().getDrawable(R.drawable.fanbutton));
        TB7.setRoomName("Air Room 1");
        TB7.setPin(new String[]{"ON", "OFF"});

        TB8 = new Setting();
        TB8.setIcon(getResources().getDrawable(R.drawable.fanbutton));
        TB8.setRoomName("Air Room 2");
        TB8.setPin(new String[]{"ON", "OFF"});

        TB9 = new Setting();
        TB9.setIcon(getResources().getDrawable(R.drawable.fanbutton));
        TB9.setRoomName("Air Room 3");
        TB9.setPin(new String[]{"ON", "OFF"});

        TB_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB1.getRoomName());
                RoomName.setText(TB1.getRoomName());
                pinon.setText(TB1.getPin()[0]);
                pinoff.setText(TB1.getPin()[1]);
            }
        });

        TB_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB2.getRoomName());
                RoomName.setText(TB2.getRoomName());
                pinon.setText(TB2.getPin()[0]);
                pinoff.setText(TB2.getPin()[1]);
            }
        });

        TB_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB3.getRoomName());
                RoomName.setText(TB3.getRoomName());
                pinon.setText(TB3.getPin()[0]);
                pinoff.setText(TB3.getPin()[1]);
            }
        });

        TB_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB4.getRoomName());
                RoomName.setText(TB4.getRoomName());
                pinon.setText(TB4.getPin()[0]);
                pinoff.setText(TB4.getPin()[1]);
            }
        });

        TB_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB5.getRoomName());
                RoomName.setText(TB5.getRoomName());
                pinon.setText(TB5.getPin()[0]);
                pinoff.setText(TB5.getPin()[1]);
            }
        });

        TB_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB6.getRoomName());
                RoomName.setText(TB6.getRoomName());
                pinon.setText(TB6.getPin()[0]);
                pinoff.setText(TB6.getPin()[1]);
            }
        });

        TB_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB7.getRoomName());
                RoomName.setText(TB7.getRoomName());
                pinon.setText(TB7.getPin()[0]);
                pinoff.setText(TB7.getPin()[1]);
            }
        });

        TB_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB8.getRoomName());
                RoomName.setText(TB8.getRoomName());
                pinon.setText(TB8.getPin()[0]);
                pinoff.setText(TB8.getPin()[1]);
            }
        });

        TB_9 .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DEMOSHOW.setText(TB9.getRoomName());
                RoomName.setText(TB9.getRoomName());
                pinon.setText(TB9.getPin()[0]);
                pinoff.setText(TB9.getPin()[1]);
            }
        });

    }

}
